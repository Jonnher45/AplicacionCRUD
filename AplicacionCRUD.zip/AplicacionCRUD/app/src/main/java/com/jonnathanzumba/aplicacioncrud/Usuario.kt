package com.jonnathanzumba.aplicacioncrud

data class Usuario(
    var idUsuario: Int,
    var nombre: String,
    var email: String
)